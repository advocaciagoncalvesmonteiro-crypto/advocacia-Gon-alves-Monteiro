import { Scale } from "lucide-react";

const ITEMS = [
  "Plantão Criminal 24h",
  "Defesa Penal",
  "Aposentadoria e INSS",
  "BPC / LOAS",
  "Direito do Trabalho",
  "Lei Maria da Penha",
  "Inventários e Divórcios",
  "Contratos e Indenizações",
];

function Strip() {
  return (
    <div className="flex w-max shrink-0 items-center">
      {ITEMS.map((label) => (
        <span key={label} className="flex items-center">
          <span className="whitespace-nowrap px-6 text-[13px] font-extrabold uppercase tracking-[0.18em] text-navy-950 sm:text-sm">
            {label}
          </span>
          <Scale className="h-4 w-4 shrink-0 text-navy-900/70" aria-hidden />
        </span>
      ))}
    </div>
  );
}

export function Marquee() {
  return (
    <div className="relative overflow-hidden border-y border-gold-600/40 bg-gradient-to-r from-gold-600 via-gold-500 to-gold-600 py-3.5">
      <div className="flex w-max animate-marquee">
        <Strip />
        <Strip />
      </div>
    </div>
  );
}
