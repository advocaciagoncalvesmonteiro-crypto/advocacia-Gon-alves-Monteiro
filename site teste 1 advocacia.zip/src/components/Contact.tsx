import { Clock, Mail, MapPin, Navigation, Phone } from "lucide-react";
import { FadeIn } from "./FadeIn";
import { SectionHeading } from "./SectionHeading";
import {
  ADDRESS_CITY,
  ADDRESS_STREET,
  EMAIL,
  MAPS_EMBED,
  MAPS_LINK,
  PHONE_DISPLAY,
  WA_GENERAL,
} from "../lib/site";

const CARDS = [
  {
    icon: MapPin,
    title: "Endereço",
    lines: [ADDRESS_STREET, ADDRESS_CITY],
    action: { label: "Traçar rota no Google Maps", href: MAPS_LINK },
    accent: "gold" as const,
  },
  {
    icon: Phone,
    title: "WhatsApp / Telefone",
    lines: [PHONE_DISPLAY, "Chamadas, mensagens e plantão"],
    action: { label: "Chamar no WhatsApp", href: WA_GENERAL },
    accent: "green" as const,
  },
  {
    icon: Mail,
    title: "E-mail",
    lines: [EMAIL, "Documentos e peticionamento"],
    action: { label: "Enviar um e-mail", href: `mailto:${EMAIL}` },
    accent: "gold" as const,
  },
  {
    icon: Clock,
    title: "Horários",
    lines: ["Segunda a Sexta · 08h às 17h", "Plantão Criminal · 24h, 7 dias"],
    action: null,
    accent: "red" as const,
  },
];

const ACCENTS = {
  gold: "border-gold-500/30 bg-gold-500/10 text-gold-400",
  green: "border-wa-500/40 bg-wa-500/10 text-wa-500",
  red: "border-alert-500/40 bg-alert-600/15 text-alert-400",
};

export function Contact() {
  return (
    <section
      id="contato"
      className="relative scroll-mt-24 border-t border-white/5 bg-navy-900/40 py-24 sm:py-28"
    >
      <div
        className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold-500/60 to-transparent"
        aria-hidden
      />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Contato"
          title={
            <>
              Estamos prontos para <span className="text-gold-gradient italic">lutar por você.</span>
            </>
          }
          description="Atendimento presencial em nosso escritório em Ananindeua ou pelo WhatsApp, onde você estiver. Envie sua mensagem e nossa equipe responde com agilidade."
        />

        <div className="mt-16 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {CARDS.map((card, i) => (
            <FadeIn key={card.title} delay={i * 0.08} className="h-full">
              <div className="flex h-full flex-col rounded-3xl border border-white/8 bg-navy-850/80 p-7 transition-all duration-500 hover:-translate-y-1.5 hover:border-gold-500/35">
                <span
                  className={`flex h-12 w-12 items-center justify-center rounded-2xl border ${ACCENTS[card.accent]}`}
                >
                  <card.icon className="h-6 w-6" />
                </span>
                <h3 className="mt-5 text-xs font-bold uppercase tracking-[0.22em] text-gold-400">
                  {card.title}
                </h3>
                <div className="mt-3 flex-1 space-y-1">
                  {card.lines.map((line) => (
                    <p key={line} className="break-words text-[14.5px] font-medium text-slate-200">
                      {line}
                    </p>
                  ))}
                </div>
                {card.action && (
                  <a
                    href={card.action.href}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-5 inline-flex items-center gap-1.5 text-[12px] font-bold uppercase tracking-wider text-gold-400 transition-colors hover:text-gold-300"
                  >
                    <Navigation className="h-3.5 w-3.5" />
                    {card.action.label}
                  </a>
                )}
              </div>
            </FadeIn>
          ))}
        </div>

        {/* Mapa */}
        <FadeIn delay={0.15}>
          <div className="relative mt-12 overflow-hidden rounded-3xl border border-gold-500/25 shadow-[0_40px_90px_-35px_rgba(0,0,0,0.9)]">
            <iframe
              title="Mapa — Advocacia Gonçalves Monteiro, Ananindeua/PA"
              src={MAPS_EMBED}
              className="map-dark h-[380px] w-full border-0 sm:h-[440px]"
              loading="lazy"
              allowFullScreen
              referrerPolicy="no-referrer-when-downgrade"
            />
            <div className="pointer-events-none absolute left-5 top-5 rounded-2xl border border-gold-500/30 bg-navy-950/90 px-5 py-4 backdrop-blur-md">
              <p className="font-display text-base font-semibold text-white">
                Advocacia Gonçalves Monteiro
              </p>
              <p className="mt-1 text-xs font-medium text-gold-300">{ADDRESS_STREET}</p>
              <p className="text-xs font-medium text-slate-400">{ADDRESS_CITY}</p>
            </div>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
