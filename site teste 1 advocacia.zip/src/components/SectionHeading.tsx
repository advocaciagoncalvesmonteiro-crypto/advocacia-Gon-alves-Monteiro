import type { ReactNode } from "react";
import { FadeIn } from "./FadeIn";
import { cn } from "../utils/cn";

interface SectionHeadingProps {
  eyebrow: string;
  title: ReactNode;
  description?: string;
  align?: "left" | "center";
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "center",
}: SectionHeadingProps) {
  const centered = align === "center";
  return (
    <FadeIn
      className={cn(
        "max-w-3xl",
        centered ? "mx-auto text-center" : "text-left"
      )}
    >
      <div
        className={cn(
          "flex items-center gap-3",
          centered && "justify-center"
        )}
      >
        <span className="h-px w-8 bg-gold-500/70" aria-hidden />
        <span className="text-[11px] font-bold uppercase tracking-[0.32em] text-gold-400 sm:text-xs">
          {eyebrow}
        </span>
        <span className="h-px w-8 bg-gold-500/70" aria-hidden />
      </div>
      <h2 className="mt-5 font-display text-3xl leading-[1.12] font-semibold text-white sm:text-4xl lg:text-[2.75rem]">
        {title}
      </h2>
      {description && (
        <p className="mt-5 text-base leading-relaxed text-slate-300/90 sm:text-lg">
          {description}
        </p>
      )}
    </FadeIn>
  );
}
