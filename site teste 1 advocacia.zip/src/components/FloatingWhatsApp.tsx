import { motion } from "framer-motion";
import { MessageCircle } from "lucide-react";
import { PHONE_DISPLAY, WA_GENERAL } from "../lib/site";

export function FloatingWhatsApp() {
  return (
    <motion.a
      href={WA_GENERAL}
      target="_blank"
      rel="noreferrer"
      aria-label={`Falar no WhatsApp ${PHONE_DISPLAY}`}
      initial={{ opacity: 0, scale: 0.5, y: 24 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ delay: 1.6, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="group fixed bottom-5 right-5 z-[60] flex items-center gap-3 sm:bottom-7 sm:right-7"
    >
      <span className="pointer-events-none hidden translate-x-3 rounded-full border border-gold-500/30 bg-navy-950/95 px-4 py-2.5 text-xs font-bold text-white opacity-0 shadow-xl backdrop-blur transition-all duration-300 group-hover:translate-x-0 group-hover:opacity-100 sm:block">
        Fale conosco · {PHONE_DISPLAY}
      </span>

      <span className="relative flex h-15 w-15 items-center justify-center sm:h-16 sm:w-16">
        <span className="absolute inset-0 animate-pulse-ring rounded-full bg-wa-500/60" />
        <span className="relative flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-wa-500 to-wa-600 text-white shadow-[0_14px_35px_-8px_rgba(37,211,102,0.65)] transition-transform duration-300 group-hover:scale-105 sm:h-16 sm:w-16">
          <MessageCircle className="h-7 w-7 fill-white" />
        </span>
      </span>
    </motion.a>
  );
}
