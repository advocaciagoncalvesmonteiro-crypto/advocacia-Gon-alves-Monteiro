import { ArrowUpRight, HardHat, HeartHandshake, Siren, ScrollText } from "lucide-react";
import { FadeIn } from "./FadeIn";
import { SectionHeading } from "./SectionHeading";
import { waLink } from "../lib/site";

const AREAS = [
  {
    number: "01",
    icon: Siren,
    tag: "Plantão 24h",
    urgent: true,
    title: "Defesa Penal e Direito Criminal",
    summary:
      "Atuação estratégica e imediata em momentos de crise. Protegemos sua liberdade com acompanhamento em delegacias, audiências de custódia, pedidos de liberdade provisória, revogação de prisão preventiva, habeas corpus e defesa completa em processos criminais e na Lei Maria da Penha.",
    message:
      "Olá! Preciso de ajuda com uma questão criminal (Plantão 24h).",
  },
  {
    number: "02",
    icon: HeartHandshake,
    tag: "Seu sustento garantido",
    urgent: false,
    title: "Direito Previdenciário (INSS)",
    summary:
      "Garantindo o seu sustento e o descanso que você merece. Especialistas em planejamento previdenciário, concessão de aposentadorias (por idade, tempo ou invalidez), pedidos e recursos de Auxílio-Doença, BPC/LOAS (idosos e PCD) e Pensão por Morte.",
    message: "Olá! Preciso de ajuda com meu benefício do INSS.",
  },
  {
    number: "03",
    icon: HardHat,
    tag: "Seus direitos resgatados",
    urgent: false,
    title: "Direito do Trabalho",
    summary:
      "Defendendo quem move o país. Se você foi demitido sem receber seus direitos, trabalha sem carteira assinada, sofreu acidente de trabalho ou não recebeu horas extras e adicionais devidos, nós buscamos a sua reparação na Justiça do Trabalho.",
    message: "Olá! Preciso de ajuda com meus direitos trabalhistas.",
  },
  {
    number: "04",
    icon: ScrollText,
    tag: "Seu patrimônio protegido",
    urgent: false,
    title: "Direito Civil e Contratos",
    summary:
      "Soluções seguras para o seu dia a dia e para o seu patrimônio. Atuamos com regularização de imóveis, inventários, divórcios, elaboração e análise de contratos, além de ações de indenização e defesa do consumidor.",
    message: "Olá! Preciso de ajuda com uma questão cível.",
  },
];

export function PracticeAreas() {
  return (
    <section id="atuacao" className="relative scroll-mt-24 bg-navy-900/40 py-24 sm:py-28">
      <div
        className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold-500/60 to-transparent"
        aria-hidden
      />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Áreas de Atuação"
          title={
            <>
              Atuação firme onde você{" "}
              <span className="text-gold-gradient italic">mais precisa.</span>
            </>
          }
          description="Do pedido de socorro em uma delegacia à aposentadoria tão sonhada: um time preparado para agir com rapidez, técnica e sensibilidade."
        />

        <div className="mt-16 grid gap-6 md:grid-cols-2">
          {AREAS.map((area, i) => (
            <FadeIn key={area.number} delay={i * 0.08}>
              <article className="group relative flex h-full flex-col overflow-hidden rounded-3xl border border-white/8 bg-navy-850/80 p-7 transition-all duration-500 hover:-translate-y-2 hover:border-gold-500/40 hover:shadow-[0_30px_70px_-25px_rgba(197,160,89,0.25)] sm:p-9">
                {/* Número */}
                <span
                  className="pointer-events-none absolute -right-2 -top-5 font-display text-[6rem] font-bold leading-none text-white/[0.045] transition-colors duration-500 group-hover:text-gold-500/10"
                  aria-hidden
                >
                  {area.number}
                </span>

                <div className="flex items-start justify-between gap-4">
                  <span
                    className={`flex h-14 w-14 items-center justify-center rounded-2xl border transition-all duration-500 ${
                      area.urgent
                        ? "border-alert-500/40 bg-alert-600/15 text-alert-400 group-hover:bg-alert-500 group-hover:text-white"
                        : "border-gold-500/30 bg-gold-500/10 text-gold-400 group-hover:bg-gold-500 group-hover:text-navy-950"
                    }`}
                  >
                    <area.icon className="h-7 w-7" />
                  </span>
                  <span
                    className={`rounded-full border px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.18em] ${
                      area.urgent
                        ? "animate-siren border-alert-500/50 bg-alert-600/20 text-alert-400"
                        : "border-gold-500/25 bg-gold-500/5 text-gold-400"
                    }`}
                  >
                    {area.tag}
                  </span>
                </div>

                <h3 className="mt-7 font-display text-2xl font-semibold leading-snug text-white">
                  {area.title}
                </h3>
                <p className="mt-4 flex-1 text-[15px] leading-relaxed text-slate-300/90">
                  {area.summary}
                </p>

                <a
                  href={waLink(area.message)}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-7 inline-flex items-center gap-2 text-[13px] font-bold uppercase tracking-[0.16em] text-gold-400 transition-colors hover:text-gold-300"
                >
                  Falar com o especialista
                  <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1" />
                </a>

                <span
                  className="absolute inset-x-0 bottom-0 h-1 origin-left scale-x-0 bg-gradient-to-r from-gold-600 via-gold-400 to-gold-600 transition-transform duration-500 group-hover:scale-x-100"
                  aria-hidden
                />
              </article>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}
