import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { MessageCircleQuestion, Plus, Siren } from "lucide-react";
import { FadeIn } from "./FadeIn";
import { SectionHeading } from "./SectionHeading";
import { WA_URGENT } from "../lib/site";
import { cn } from "../utils/cn";

const FAQS = [
  {
    question: "O que fazer se um familiar for preso em flagrante?",
    answer:
      "O acompanhamento de um advogado nas primeiras horas (na delegacia) é fundamental para garantir os direitos constitucionais e evitar abusos. Entre em contato imediato com nosso Plantão 24h pelo botão vermelho no topo do site.",
  },
  {
    question: "Tive o meu benefício do INSS negado. O que devo fazer?",
    answer:
      "Não se desespere. O INSS nega milhares de benefícios injustamente todos os meses. É possível ingressar com uma ação judicial para reverter a decisão e, muitas vezes, receber todos os valores retroativos desde o primeiro pedido.",
  },
  {
    question:
      "Fui demitido e a empresa não pagou meus direitos. Qual o prazo para processar?",
    answer:
      "O trabalhador tem o prazo limite de até 2 anos após a demissão para entrar com uma ação na Justiça do Trabalho e cobrar os direitos dos últimos 5 anos trabalhados.",
  },
  {
    question: "Como funciona o primeiro atendimento?",
    answer:
      "O primeiro contato é feito pelo WhatsApp, de forma rápida e sigilosa. Analisamos preliminarmente o seu caso, orientamos sobre os documentos necessários e agendamos a consulta — presencial no escritório em Ananindeua ou on-line — no melhor horário para você.",
  },
  {
    question: "Vocês atendem apenas em Ananindeua?",
    answer:
      "Nosso escritório está sediado em Ananindeua e atuamos em Belém e em toda a Região Metropolitana. No Plantão Criminal, o atendimento é 24 horas, todos os dias da semana, incluindo acompanhamento em delegacias da região.",
  },
];

export function Faq() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="duvidas" className="relative scroll-mt-24 overflow-hidden py-24 sm:py-28">
      <div className="gold-glow absolute -right-40 top-0 h-[28rem] w-[28rem]" aria-hidden />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-14 lg:grid-cols-[1fr_1.35fr] lg:gap-20">
          {/* Coluna fixa */}
          <div className="lg:sticky lg:top-36 lg:self-start">
            <SectionHeading
              align="left"
              eyebrow="Central de Dúvidas"
              title={
                <>
                  Perguntas <span className="text-gold-gradient italic">frequentes.</span>
                </>
              }
              description="Reunimos as dúvidas que mais chegam até o nosso escritório. Se a sua não estiver aqui, fale diretamente com a nossa equipe — o atendimento é rápido, sigiloso e humanizado."
            />

            <FadeIn delay={0.15}>
              <div className="mt-9 rounded-2xl border border-alert-500/30 bg-alert-600/10 p-6">
                <div className="flex items-center gap-3">
                  <Siren className="h-6 w-6 text-alert-400" />
                  <p className="font-display text-lg font-semibold text-white">
                    Situação de urgência agora?
                  </p>
                </div>
                <p className="mt-2 text-sm leading-relaxed text-slate-300">
                  Prisão em flagrante, audiência de custódia ou delegacia: nosso Plantão Criminal
                  funciona 24 horas, todos os dias.
                </p>
                <a
                  href={WA_URGENT}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-4 inline-flex items-center gap-2 rounded-full bg-alert-600 px-5 py-3 text-xs font-bold uppercase tracking-wider text-white transition-colors hover:bg-alert-500"
                >
                  Acionar Plantão 24h
                </a>
              </div>
            </FadeIn>
          </div>

          {/* Acordeão */}
          <div className="space-y-4">
            {FAQS.map((faq, i) => {
              const isOpen = openIndex === i;
              return (
                <FadeIn key={faq.question} delay={i * 0.06}>
                  <div
                    className={cn(
                      "overflow-hidden rounded-2xl border transition-colors duration-300",
                      isOpen
                        ? "border-gold-500/45 bg-navy-850/90"
                        : "border-white/8 bg-navy-900/60 hover:border-gold-500/25"
                    )}
                  >
                    <button
                      onClick={() => setOpenIndex(isOpen ? null : i)}
                      aria-expanded={isOpen}
                      className="flex w-full items-center gap-4 px-6 py-5 text-left"
                    >
                      <span
                        className={cn(
                          "flex h-9 w-9 shrink-0 items-center justify-center rounded-full border transition-colors",
                          isOpen
                            ? "border-gold-500 bg-gold-500 text-navy-950"
                            : "border-gold-500/30 text-gold-400"
                        )}
                      >
                        <MessageCircleQuestion className="h-4.5 w-4.5" />
                      </span>
                      <span
                        className={cn(
                          "flex-1 text-[15px] font-semibold leading-snug sm:text-base",
                          isOpen ? "text-white" : "text-slate-200"
                        )}
                      >
                        {faq.question}
                      </span>
                      <span
                        className={cn(
                          "flex h-8 w-8 shrink-0 items-center justify-center rounded-full border transition-all duration-300",
                          isOpen
                            ? "rotate-45 border-gold-500 bg-gold-500 text-navy-950"
                            : "border-gold-500/30 text-gold-400"
                        )}
                      >
                        <Plus className="h-4 w-4" />
                      </span>
                    </button>

                    <AnimatePresence initial={false}>
                      {isOpen && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                        >
                          <p className="px-6 pb-6 pl-[4.75rem] text-[14.5px] leading-relaxed text-slate-300">
                            {faq.answer}
                          </p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </FadeIn>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
