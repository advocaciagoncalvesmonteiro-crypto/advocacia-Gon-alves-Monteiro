import { ArrowRight, BadgeCheck, CheckCircle2, Scale } from "lucide-react";
import { FadeIn } from "./FadeIn";
import { SectionHeading } from "./SectionHeading";
import { WA_GENERAL } from "../lib/site";
import { drJhonata } from "../lib/assets";

const PILLARS = [
  "Atendimento humanizado, próximo e sigiloso",
  "Agilidade e estratégia em cada processo",
  "Postura combativa na defesa dos seus direitos",
];

export function About() {
  return (
    <section id="quem-somos" className="relative scroll-mt-24 overflow-hidden py-24 sm:py-28">
      <div className="bg-grid-gold absolute inset-0 opacity-60" aria-hidden />
      <div className="gold-glow absolute -left-40 top-1/3 h-[30rem] w-[30rem]" aria-hidden />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-16 lg:grid-cols-2 lg:gap-20">
          {/* Retrato */}
          <FadeIn className="relative mx-auto w-full max-w-md lg:max-w-none">
            <div className="relative">
              <div
                className="absolute -inset-3 rounded-[1.75rem] border border-gold-500/35 sm:-inset-4"
                aria-hidden
              />
              <div className="absolute -left-3 -top-3 h-24 w-24 rounded-tl-[1.75rem] border-l-2 border-t-2 border-gold-500 sm:-left-4 sm:-top-4" aria-hidden />
              <div className="absolute -bottom-3 -right-3 h-24 w-24 rounded-br-[1.75rem] border-b-2 border-r-2 border-gold-500 sm:-bottom-4 sm:-right-4" aria-hidden />

              <img
                src={drJhonata}
                alt="Dr. Jhonata Gonçalves Monteiro em seu escritório de advocacia"
                className="aspect-[4/5] w-full rounded-[1.5rem] object-cover shadow-[0_40px_80px_-30px_rgba(0,0,0,0.9)]"
                loading="lazy"
              />

              {/* Cartão flutuante */}
              <div className="absolute -bottom-7 left-1/2 w-[88%] max-w-xs -translate-x-1/2 rounded-2xl border border-gold-500/30 bg-navy-900/95 p-5 shadow-[0_24px_60px_-20px_rgba(0,0,0,0.9)] backdrop-blur-md sm:left-auto sm:right-[-1.5rem] sm:translate-x-0">
                <div className="flex items-center gap-3">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gold-500/15 text-gold-400">
                    <BadgeCheck className="h-6 w-6" />
                  </span>
                  <div>
                    <p className="font-display text-base font-semibold leading-tight text-white">
                      Dr. Jhonata Gonçalves Monteiro
                    </p>
                    <p className="mt-0.5 text-xs font-bold uppercase tracking-[0.18em] text-gold-400">
                      OAB/PA 29.571
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div
              className="absolute -right-6 -top-8 flex h-20 w-20 animate-float items-center justify-center rounded-full border border-gold-500/40 bg-navy-900 text-gold-400 shadow-xl sm:-right-8 sm:h-24 sm:w-24"
              aria-hidden
            >
              <Scale className="h-9 w-9 sm:h-10 sm:w-10" />
            </div>
          </FadeIn>

          {/* Texto */}
          <div>
            <SectionHeading
              align="left"
              eyebrow="Quem Somos"
              title={
                <>
                  Experiência, Combatividade{" "}
                  <span className="text-gold-gradient italic">e Transparência.</span>
                </>
              }
            />

            <FadeIn delay={0.1}>
              <p className="mt-7 text-[15px] leading-relaxed text-slate-300 sm:text-base">
                Fundada com o propósito de oferecer uma prestação jurisdicional de excelência, a
                Advocacia Gonçalves Monteiro é um escritório de destaque na cidade de Ananindeua e
                região. Sob a liderança do{" "}
                <strong className="font-semibold text-white">
                  Dr. Jhonata Gonçalves Monteiro (OAB/PA 29.571)
                </strong>
                , nossa atuação é pautada pelo atendimento humanizado, pela agilidade e pelo
                compromisso inegociável com os direitos de nossos clientes.
              </p>
              <p className="mt-5 text-[15px] leading-relaxed text-slate-300 sm:text-base">
                Entendemos que por trás de cada processo existe uma vida, uma família ou um
                trabalhador em busca de justiça. Por isso, aliamos conhecimento técnico de vanguarda
                a uma postura combativa — seja na defesa intransigente da liberdade em causas penais
                urgentes, seja garantindo a subsistência de segurados do INSS e trabalhadores. No
                momento em que você mais precisa de um apoio jurídico seguro, nós estamos prontos
                para lutar por você.
              </p>
            </FadeIn>

            <FadeIn delay={0.18}>
              <ul className="mt-8 space-y-3.5">
                {PILLARS.map((pillar) => (
                  <li key={pillar} className="flex items-start gap-3">
                    <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-gold-400" />
                    <span className="text-[15px] font-medium text-slate-200">{pillar}</span>
                  </li>
                ))}
              </ul>
            </FadeIn>

            <FadeIn delay={0.24}>
              <a
                href={WA_GENERAL}
                target="_blank"
                rel="noreferrer"
                className="group mt-9 inline-flex items-center gap-3 text-sm font-bold uppercase tracking-[0.18em] text-gold-400 transition-colors hover:text-gold-300"
              >
                Converse com o Dr. Jhonata
                <span className="flex h-9 w-9 items-center justify-center rounded-full border border-gold-500/50 transition-all duration-300 group-hover:bg-gold-500 group-hover:text-navy-950">
                  <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5" />
                </span>
              </a>
            </FadeIn>
          </div>
        </div>
      </div>
    </section>
  );
}
