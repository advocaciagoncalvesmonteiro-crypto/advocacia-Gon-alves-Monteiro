import { Gavel, Mail, MapPin, Phone } from "lucide-react";
import type { SVGProps } from "react";
import { EMAIL, PHONE_DISPLAY, SOCIAL, WA_GENERAL } from "../lib/site";
import { logo } from "../lib/assets";

function FacebookIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden {...props}>
      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
    </svg>
  );
}

function InstagramIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
      {...props}
    >
      <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
    </svg>
  );
}

const NAV = [
  { label: "Início", href: "#inicio" },
  { label: "Quem Somos", href: "#quem-somos" },
  { label: "Áreas de Atuação", href: "#atuacao" },
  { label: "Dúvidas Frequentes", href: "#duvidas" },
  { label: "Contato", href: "#contato" },
];

const AREAS = [
  "Defesa Penal e Plantão 24h",
  "Direito Previdenciário (INSS)",
  "Direito do Trabalho",
  "Direito Civil e Contratos",
];

const SOCIAL_LINKS = [
  { icon: FacebookIcon, label: "Facebook", href: SOCIAL.facebook },
  { icon: InstagramIcon, label: "Instagram", href: SOCIAL.instagram },
  { icon: Gavel, label: "Jusbrasil", href: SOCIAL.jusbrasil },
];

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-gold-500/15 bg-navy-950">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          {/* Marca */}
          <div>
            <a href="#inicio" className="flex items-center gap-3">
              <img
                src={logo}
                alt="Monograma Advocacia Gonçalves Monteiro"
                className="h-14 w-14 rounded-full object-cover ring-1 ring-gold-500/50"
              />
              <span className="leading-none">
                <span className="block text-[10px] font-bold uppercase tracking-[0.34em] text-gold-400">
                  Advocacia
                </span>
                <span className="mt-1 block font-display text-xl font-semibold text-white">
                  Gonçalves Monteiro
                </span>
              </span>
            </a>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-slate-400">
              Defesa técnica, humanizada e estratégica para proteger sua liberdade, seu trabalho e o
              seu futuro. Atuação firme em Ananindeua e em toda a Região Metropolitana de Belém.
            </p>
            <div className="mt-6 flex items-center gap-3">
              {SOCIAL_LINKS.map(({ icon: Icon, label, href }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={label}
                  title={label}
                  className="flex h-10 w-10 items-center justify-center rounded-full border border-gold-500/30 text-gold-400 transition-all duration-300 hover:-translate-y-1 hover:bg-gold-500 hover:text-navy-950"
                >
                  <Icon className="h-4.5 w-4.5" />
                </a>
              ))}
            </div>
          </div>

          {/* Navegação */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-[0.24em] text-gold-400">
              Navegação
            </h3>
            <ul className="mt-5 space-y-3">
              {NAV.map((item) => (
                <li key={item.href}>
                  <a
                    href={item.href}
                    className="text-sm text-slate-400 transition-colors hover:text-gold-300"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Áreas */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-[0.24em] text-gold-400">
              Atuação
            </h3>
            <ul className="mt-5 space-y-3">
              {AREAS.map((area) => (
                <li key={area} className="text-sm text-slate-400">
                  {area}
                </li>
              ))}
            </ul>
          </div>

          {/* Contato */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-[0.24em] text-gold-400">
              Contato
            </h3>
            <ul className="mt-5 space-y-4 text-sm text-slate-400">
              <li className="flex items-start gap-3">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-gold-500" />
                <span>
                  Tv. WE 68, nº 922 — Cidade Nova VI,
                  <br />
                  Ananindeua/PA · CEP 67140-100
                </span>
              </li>
              <li>
                <a
                  href={`tel:+5591983001303`}
                  className="flex items-center gap-3 transition-colors hover:text-gold-300"
                >
                  <Phone className="h-4 w-4 shrink-0 text-gold-500" />
                  {PHONE_DISPLAY}
                </a>
              </li>
              <li>
                <a
                  href={`mailto:${EMAIL}`}
                  className="flex items-start gap-3 break-all transition-colors hover:text-gold-300"
                >
                  <Mail className="mt-0.5 h-4 w-4 shrink-0 text-gold-500" />
                  {EMAIL}
                </a>
              </li>
            </ul>
            <a
              href={WA_GENERAL}
              target="_blank"
              rel="noreferrer"
              className="mt-6 inline-flex items-center gap-2 rounded-full border border-gold-500/50 bg-gold-500/10 px-5 py-2.5 text-[11px] font-bold uppercase tracking-wider text-gold-300 transition-all duration-300 hover:bg-gold-500 hover:text-navy-950"
            >
              Falar no WhatsApp
            </a>
          </div>
        </div>
      </div>

      <div className="border-t border-white/5">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 py-6 text-center sm:px-6 md:flex-row md:text-left lg:px-8">
          <p className="text-xs text-slate-500">
            © {year} Advocacia Gonçalves Monteiro — Todos os direitos reservados.
          </p>
          <p className="text-xs font-semibold text-gold-500/80">
            Dr. Jhonata Gonçalves Monteiro · OAB/PA 29.571
          </p>
          <p className="max-w-md text-[10px] leading-relaxed text-slate-600">
            Site de caráter exclusivamente informativo, em conformidade com o Provimento nº
            205/2021 do CFOAB.
          </p>
        </div>
      </div>
    </footer>
  );
}
