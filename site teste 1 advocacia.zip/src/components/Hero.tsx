import { motion, type Variants } from "framer-motion";
import {
  CalendarCheck,
  ChevronDown,
  Clock4,
  MapPin,
  Siren,
  ShieldCheck,
} from "lucide-react";
import { WA_SCHEDULE, WA_URGENT } from "../lib/site";
import { heroBg } from "../lib/assets";

const container: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.14, delayChildren: 0.2 } },
};

const item: Variants = {
  hidden: { opacity: 0, y: 34 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.85, ease: [0.22, 1, 0.36, 1] },
  },
};

export function Hero() {
  return (
    <section id="inicio" className="relative flex min-h-[100svh] items-center overflow-hidden">
      {/* Fundo cinematográfico */}
      <div className="absolute inset-0">
        <img
          src={heroBg}
          alt="Escritório de advocacia elegante"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-navy-950 via-navy-950/85 to-navy-950/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-transparent to-navy-950/70" />
        <div className="gold-glow absolute -top-32 right-[-10%] h-[34rem] w-[34rem]" />
      </div>

      <div className="relative z-10 mx-auto w-full max-w-7xl px-4 pb-28 pt-36 sm:px-6 md:pt-40 lg:px-8">
        <motion.div variants={container} initial="hidden" animate="show" className="max-w-3xl">
          <motion.div
            variants={item}
            className="inline-flex items-center gap-2.5 rounded-full border border-gold-500/35 bg-navy-900/60 px-4 py-2 backdrop-blur"
          >
            <ShieldCheck className="h-4 w-4 text-gold-400" />
            <span className="text-[11px] font-semibold uppercase tracking-[0.22em] text-gold-300 sm:text-xs">
              OAB/PA 29.571 · Ananindeua e Região Metropolitana de Belém
            </span>
          </motion.div>

          <motion.h1
            variants={item}
            className="mt-7 font-display text-[2.6rem] font-semibold leading-[1.06] text-white sm:text-6xl lg:text-[4.4rem]"
          >
            Advocacia{" "}
            <span className="text-gold-gradient italic">Gonçalves</span>
            <br />
            <span className="text-gold-gradient italic">Monteiro</span>
          </motion.h1>

          <motion.div variants={item} className="gold-line mt-7 h-px w-40" />

          <motion.p
            variants={item}
            className="mt-7 max-w-2xl text-base leading-relaxed text-slate-300 sm:text-lg"
          >
            Defesa técnica, humanizada e estratégica para proteger sua{" "}
            <strong className="font-semibold text-white">liberdade</strong>, seu{" "}
            <strong className="font-semibold text-white">trabalho</strong> e o seu{" "}
            <strong className="font-semibold text-white">futuro</strong>. Atuação firme em
            Ananindeua e em toda a Região Metropolitana de Belém.
          </motion.p>

          <motion.div variants={item} className="mt-10 flex flex-col gap-4 sm:flex-row sm:items-center">
            <a
              href={WA_URGENT}
              target="_blank"
              rel="noreferrer"
              className="group flex items-center justify-center gap-3 rounded-full bg-alert-600 px-7 py-4 text-sm font-bold uppercase tracking-wider text-white shadow-[0_14px_40px_-10px_rgba(211,47,47,0.55)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-alert-500 sm:justify-start"
            >
              <span className="relative flex h-6 w-6 items-center justify-center">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-white/30" />
                <Siren className="relative h-5 w-5" />
              </span>
              <span className="text-left leading-tight">
                Urgência Criminal?
                <span className="block text-[11px] font-semibold tracking-normal normal-case text-white/85">
                  Fale agora com o Plantão 24h
                </span>
              </span>
            </a>

            <a
              href={WA_SCHEDULE}
              target="_blank"
              rel="noreferrer"
              className="group flex items-center justify-center gap-3 rounded-full border border-gold-500/60 bg-gold-500/10 px-7 py-4 text-sm font-bold uppercase tracking-wider text-gold-300 backdrop-blur transition-all duration-300 hover:-translate-y-0.5 hover:bg-gold-500 hover:text-navy-950 sm:justify-start"
            >
              <CalendarCheck className="h-5 w-5" />
              Agendar Consulta
              <span className="hidden text-[11px] font-semibold normal-case tracking-normal opacity-80 sm:inline">
                INSS · Trabalhista · Cível
              </span>
            </a>
          </motion.div>

          <motion.div
            variants={item}
            className="mt-12 flex flex-wrap items-center gap-x-8 gap-y-4 border-t border-white/10 pt-7"
          >
            {[
              { icon: Clock4, text: "Plantão Criminal 24h · 7 dias por semana" },
              { icon: MapPin, text: "Atendimento em Ananindeua, Belém e RMB" },
              { icon: ShieldCheck, text: "Atendimento humanizado e sigiloso" },
            ].map(({ icon: Icon, text }) => (
              <div key={text} className="flex items-center gap-2.5 text-[13px] font-medium text-slate-300">
                <Icon className="h-4 w-4 shrink-0 text-gold-400" />
                {text}
              </div>
            ))}
          </motion.div>
        </motion.div>
      </div>

      {/* Indicador de rolagem */}
      <motion.a
        href="#quem-somos"
        aria-label="Rolar para o próximo conteúdo"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4, duration: 0.8 }}
        className="absolute bottom-7 left-1/2 z-10 hidden -translate-x-1/2 flex-col items-center gap-2 text-gold-400/80 transition-colors hover:text-gold-300 sm:flex"
      >
        <span className="text-[10px] font-bold uppercase tracking-[0.3em]">Conheça o escritório</span>
        <ChevronDown className="h-5 w-5 animate-bounce-soft" />
      </motion.a>
    </section>
  );
}
