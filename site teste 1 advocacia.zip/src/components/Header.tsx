import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Clock, MapPin, Menu, Phone, Scale, Siren, X } from "lucide-react";
import { PHONE_DISPLAY, WA_SCHEDULE, WA_URGENT } from "../lib/site";
import { logo } from "../lib/assets";
import { cn } from "../utils/cn";

const NAV = [
  { label: "Início", href: "#inicio" },
  { label: "Quem Somos", href: "#quem-somos" },
  { label: "Áreas de Atuação", href: "#atuacao" },
  { label: "Dúvidas Frequentes", href: "#duvidas" },
  { label: "Contato", href: "#contato" },
];

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <a href="#inicio" className="group flex items-center gap-3">
      <span className="relative">
        <img
          src={logo}
          alt="Monograma Advocacia Gonçalves Monteiro"
          className={cn(
            "rounded-full object-cover ring-1 ring-gold-500/50 transition-transform duration-500 group-hover:scale-105",
            compact ? "h-11 w-11" : "h-12 w-12"
          )}
        />
        <span className="absolute inset-0 rounded-full bg-gold-500/10 opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
      </span>
      <span className="leading-none">
        <span className="block text-[10px] font-bold uppercase tracking-[0.34em] text-gold-400">
          Advocacia
        </span>
        <span className="mt-1 block font-display text-lg font-semibold text-white sm:text-xl">
          Gonçalves Monteiro
        </span>
      </span>
    </a>
  );
}

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <>
      {/* Barra superior institucional */}
      <div className="fixed inset-x-0 top-0 z-50 hidden border-b border-gold-500/10 bg-navy-950/95 backdrop-blur-md md:block">
        <div className="mx-auto flex h-9 max-w-7xl items-center justify-between px-6 text-[11px] font-medium tracking-wide text-slate-400 lg:px-8">
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5">
              <MapPin className="h-3.5 w-3.5 text-gold-500" />
              Ananindeua · Região Metropolitana de Belém
            </span>
            <span className="flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5 text-gold-500" />
              Seg–Sex · 08h às 17h
            </span>
            <span className="flex items-center gap-1.5 text-alert-400">
              <Siren className="h-3.5 w-3.5" />
              Plantão Criminal 24h
            </span>
          </div>
          <a
            href={`tel:+55${"91983001303"}`}
            className="flex items-center gap-1.5 text-gold-300 transition-colors hover:text-gold-200"
          >
            <Phone className="h-3.5 w-3.5" />
            {PHONE_DISPLAY}
          </a>
        </div>
      </div>

      {/* Cabeçalho principal */}
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-40 transition-all duration-500 md:top-9",
          scrolled
            ? "border-b border-gold-500/15 bg-navy-950/90 shadow-[0_10px_40px_-15px_rgba(0,0,0,0.8)] backdrop-blur-xl"
            : "bg-transparent"
        )}
      >
        <div className="mx-auto flex h-[72px] max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <Logo compact={scrolled} />

          <nav className="hidden items-center gap-7 lg:flex">
            {NAV.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="relative text-[13px] font-semibold uppercase tracking-wider text-slate-300 transition-colors after:absolute after:-bottom-1.5 after:left-0 after:h-px after:w-0 after:bg-gold-500 after:transition-all after:duration-300 hover:text-gold-300 hover:after:w-full"
              >
                {item.label}
              </a>
            ))}
          </nav>

          <div className="hidden items-center gap-3 lg:flex">
            <a
              href={WA_URGENT}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 rounded-full bg-alert-600 px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-white transition-all duration-300 hover:bg-alert-500 hover:shadow-[0_8px_24px_-6px_rgba(211,47,47,0.6)]"
            >
              <Siren className="h-4 w-4" />
              Plantão 24h
            </a>
            <a
              href={WA_SCHEDULE}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 rounded-full border border-gold-500/50 bg-gold-500/10 px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-gold-300 transition-all duration-300 hover:bg-gold-500 hover:text-navy-950"
            >
              Agendar Consulta
            </a>
          </div>

          <button
            onClick={() => setOpen(true)}
            aria-label="Abrir menu"
            className="flex h-11 w-11 items-center justify-center rounded-full border border-gold-500/30 bg-navy-900/60 text-gold-300 backdrop-blur transition-colors hover:bg-gold-500 hover:text-navy-950 lg:hidden"
          >
            <Menu className="h-5 w-5" />
          </button>
        </div>
      </header>

      {/* Menu mobile */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-[70] flex flex-col bg-navy-950/98 backdrop-blur-xl lg:hidden"
          >
            <div className="flex h-[72px] items-center justify-between px-4 sm:px-6">
              <Logo compact />
              <button
                onClick={() => setOpen(false)}
                aria-label="Fechar menu"
                className="flex h-11 w-11 items-center justify-center rounded-full border border-gold-500/30 bg-navy-900/60 text-gold-300 transition-colors hover:bg-gold-500 hover:text-navy-950"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <nav className="flex flex-1 flex-col justify-center gap-1 px-8">
              {NAV.map((item, i) => (
                <motion.a
                  key={item.href}
                  href={item.href}
                  onClick={() => setOpen(false)}
                  initial={{ opacity: 0, x: -24 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.08 + i * 0.06, duration: 0.4 }}
                  className="group flex items-center justify-between border-b border-white/5 py-4 font-display text-2xl font-semibold text-white transition-colors hover:text-gold-400"
                >
                  {item.label}
                  <Scale className="h-5 w-5 text-gold-500/50 transition-all group-hover:text-gold-400" />
                </motion.a>
              ))}
            </nav>

            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.4 }}
              className="flex flex-col gap-3 px-8 pb-10"
            >
              <a
                href={WA_URGENT}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-2 rounded-full bg-alert-600 px-6 py-4 text-sm font-bold uppercase tracking-wider text-white"
              >
                <Siren className="h-5 w-5" />
                Urgência Criminal — Plantão 24h
              </a>
              <a
                href={WA_SCHEDULE}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-2 rounded-full border border-gold-500/50 bg-gold-500/10 px-6 py-4 text-sm font-bold uppercase tracking-wider text-gold-300"
              >
                Agendar Consulta
              </a>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
