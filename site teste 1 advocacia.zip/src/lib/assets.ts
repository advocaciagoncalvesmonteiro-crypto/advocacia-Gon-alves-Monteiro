import logo from "../assets/logo.png";
import drJhonata from "../assets/dr-jhonata.jpg";
import heroBg from "../assets/hero-bg.jpg";

export { logo, drJhonata, heroBg };
