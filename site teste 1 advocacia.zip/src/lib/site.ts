export const FIRM_NAME = "Advocacia Gonçalves Monteiro";
export const LAWYER = "Dr. Jhonata Gonçalves Monteiro";
export const OAB = "OAB/PA 29.571";

export const PHONE_DISPLAY = "(91) 98300-1303";
export const PHONE_WA = "5591983001303";
export const EMAIL = "advocaciagoncalvesmonteiro@gmail.com";
export const ADDRESS_STREET = "Tv. WE 68, nº 922 — Cidade Nova VI";
export const ADDRESS_CITY = "Ananindeua/PA · CEP 67140-100";
export const ADDRESS_FULL = `${ADDRESS_STREET}, ${ADDRESS_CITY}`;

const MAPS_QUERY = "Tv. WE 68, 922 - Cidade Nova VI, Ananindeua - PA, 67140-100";
export const MAPS_EMBED = `https://www.google.com/maps?q=${encodeURIComponent(
  MAPS_QUERY
)}&output=embed`;
export const MAPS_LINK = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
  MAPS_QUERY
)}`;

export const SOCIAL = {
  facebook: "https://www.facebook.com/advocaciagoncalvesmonteiro",
  instagram: "https://www.instagram.com/advocaciagoncalvesmonteiro",
  jusbrasil: "https://www.jusbrasil.com.br/advogados",
};

export function waLink(message: string) {
  return `https://wa.me/${PHONE_WA}?text=${encodeURIComponent(message)}`;
}

export const WA_URGENT = waLink(
  "URGÊNCIA CRIMINAL — Preciso de atendimento imediato do Plantão 24h."
);
export const WA_SCHEDULE = waLink(
  "Olá! Gostaria de agendar uma consulta (INSS, Trabalhista ou Cível)."
);
export const WA_GENERAL = waLink(
  "Olá! Vim pelo site e gostaria de falar com a Advocacia Gonçalves Monteiro."
);
